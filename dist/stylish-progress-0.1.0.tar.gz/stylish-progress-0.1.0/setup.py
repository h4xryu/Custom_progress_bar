from setuptools import setup, find_packages

setup(
    name="stylish-progress",
    version="0.1.0",
    description="A stylish progress bar library with beautiful visual interface",
    author="RyuHa Kim",
    author_email="rhk04@yonsei.ac.kr",
    packages=find_packages(),
    install_requires=[
        "torch>=1.7.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
) 